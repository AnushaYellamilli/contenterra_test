import { Component } from "@angular/core";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  posts = [
    { userId: 1, postName: "post 1" },
    { userId: 2, postName: "post 2" },
    { userId: 1, postName: "post 3" },
    { userId: 2, postName: "post 4" },
    { userId: 1, postName: "post 5" },
    { userId: 3, postName: "post 6" },
    { userId: 3, postName: "post 7" },
    { userId: 4, postName: "post 8" }
  ];
  usersPostsCount = [];
  weatherData = [
    {
      id: 4845,
      applicable_date: "2022-03-29",
      min_temp: 3.64,
      max_temp: 17.240000000000003,
      city: "Delhi"
    },
    {
      id: 4845,
      applicable_date: "2022-03-28",
      min_temp: 1.0,
      max_temp: 16.240000000000003,
      city: "Bangalore"
    },
    {
      id: 4845,
      applicable_date: "2022-03-28",
      min_temp: 3.64,
      max_temp: 17.240000000000003,
      city: "hyderabad"
    }
  ];
  ngOnInit() {
    this.getUsersPostCount();
    // this.getAllNumbers();
    // this.findMissingNumbers();
  }

  getUsersPostCount() {
    var valueArr = this.posts.map(function (item) {
      return item.userId;
    });
    var result = valueArr.reduce((obj, num) => {
      obj[num] = ++obj[num] || 1;
      return obj;
    }, {});
    for (const [key, value] of Object.entries(result)) {
      let userPosts = {};
      userPosts.userId = key;
      userPosts.postCount = value;
      this.usersPostsCount.push(userPosts);
    }
    console.log("usersPostsCount", JSON.stringify(this.usersPostsCount));
  }

  getSumDigit(n) {
    let sum = 0;
    while (n) {
      let digit = n % 10;
      sum += digit;
      n = (n - digit) / 10;
    }
    return sum;
  }

  sumDigitRecur(n) {
    let sum = this.getSumDigit(n);
    if (sum < 10) {
      return sum;
    }
    return this.sumDigitRecur(sum);
  }
  getAllNumbers() {
    let singleDigitNum = [];
    for (let i = 1; i <= 9999; i++) {
      let sum = this.sumDigitRecur(i);
      if (sum === 9) singleDigitNum.push(i);
    }
    console.log("Sum Of Digits :" + singleDigitNum);
    return singleDigitNum;
  }

  findMissingNumbers() {
    let num = [5, 7, 1, 9, 2, 3, 11, 20];
    const missing = [];
    const maxValue = Math.max(...num);
    const minValue = Math.min(...num);
    for (let i = minValue; i <= maxValue; i++) {
      if (!num.includes(i)) {
        missing.push(i);
      }
    }
    console.log("Missing Numbers :" + missing);
    return missing;
  }
  getWeatherResults() {
    var arrMap = new Map();
    for (let i = 0; i < this.weatherData.length; i++) {
      if (arrMap.has(this.weatherData[i].applicable_date)) {
        const mapItemArr = [];
        mapItemArr.push(arrMap.get(this.weatherData[i].applicable_date));
        mapItemArr.push(this.weatherData[i]);
        arrMap.set(this.weatherData[i].applicable_date, mapItemArr);
      } else {
        arrMap.set(this.weatherData[i].applicable_date, this.weatherData[i]);
      }
    }
    let resultArray = [];
    arrMap.forEach((value, key) => {
      let result = {};
      if (!Array.isArray(value)) {
        result = this.getMinAndMax(key, [value]);
      } else {
        result = this.getMinAndMax(key, value);
      }
      resultArray.push(result);
    });
    console.log("result:" + JSON.stringify(resultArray));
  }

  getMinAndMax(key, value) {
    let minTempArray = [];
    let maxTempArray = [];
    let obj = {};
    obj.applicable_date = key;
    for (let i = 0; i < value.length; i++) {
      minTempArray.push(value[i].min_temp);
      maxTempArray.push(value[i].max_temp);
    }
    let minTemp = Math.min(...minTempArray);
    let maxTemp = Math.max(...maxTempArray);
    let min_temp_city = "";
    let max_temp_city = "";
    for (let i = 0; i < value.length; i++) {
      if (value[i].min_temp === minTemp) {
        min_temp_city = value[i].city;
      }
      if (value[i].max_temp === maxTemp) {
        max_temp_city = value[i].city;
      }
    }
    obj.min_temp = minTemp;
    obj.min_temp_city = min_temp_city;
    obj.max_temp = maxTemp;
    obj.max_temp_city = max_temp_city;
    return obj;
  }
}
